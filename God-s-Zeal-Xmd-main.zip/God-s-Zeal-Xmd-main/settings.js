const settings = {
  packname: '𝐆𝐎𝐃𝐒𝐙𝐄𝐀𝐋 𝐗𝐌𝐃',
  author: '‎Gods Zeal †',
  botName: "𝐆𝐎𝐃𝐒𝐙𝐄𝐀𝐋 𝐗𝐌𝐃",
  botOwner: 'Gods Zeal †', // Your name
  ownerNumber: '2348089336992', // Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  zeaburApiKey: 'sk-uopp5bz647ennuikerwn2clunfj2f', // 🔹 Added Zeabur API key here
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.0.8",
  updateZipUrl: "https://github.com/AiOfLautech/God-s-Zeal-Xmd/archive/refs/heads/main.zip",
};

module.exports = settings;
